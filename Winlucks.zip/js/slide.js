$(".sldimg1").slick({
  arrows: true,
  dots: false,
  prevArrow:
    '<span class="prev_button"><img src="./img/01.png" alt=""></span>',
  nextArrow:
    '<span class="next_button"><img src="./img/02.png" alt=""></span>',
  infinite: true,
  slidesToShow: 4,
  pauseOnHover: false,
  dragable: false,
  slidesToScroll: 1,
  autoplay: false,
  swipeToSlide: true,
  speed: 1000,

  responsive: [
    {
      breakpoint: 1400,
      settings: {
        slidesToShow: 4,
      },
    },
    {
      breakpoint: 992,
      settings: {
        slidesToShow: 3,
      },
    },
    {
      breakpoint: 780,
      settings: {
        slidesToShow: 2,
      },
    },
    {
      breakpoint: 476,
      settings: {
        slidesToShow: 1,
      },
    },
  ],
});
$(".sldimg2").slick({
  arrows: true,
  dots: false,
  prevArrow:
    '<span class="prev_button"><img src="./img/01.png" alt=""></span>',
  nextArrow:
    '<span class="next_button"><img src="./img/02.png" alt=""></span>',
  infinite: true,
  slidesToShow: 4,
  pauseOnHover: false,
  dragable: false,
  slidesToScroll: 1,
  swipeToSlide: true,
  autoplay: false,
  speed: 1000,

  responsive: [
    {
      breakpoint: 1400,
      settings: {
        slidesToShow: 4,
      },
    },
    {
      breakpoint: 992,
      settings: {
        slidesToShow: 3,
      },
    },
    {
      breakpoint: 768,
      settings: {
        slidesToShow: 2,
      },
    },
    {
      breakpoint: 576,
      settings: {
        slidesToShow: 1,
      },
    },
  ],
});
$(".sldimg3").slick({
  arrows: true,
  dots: false,
  prevArrow:
    '<span class="prev_button"><img src="./img/01.png" alt=""></span>',
  nextArrow:
    '<span class="next_button"><img src="./img/02.png" alt=""></span>',
  infinite: true,
  slidesToShow: 2,
  pauseOnHover: false,
  dragable: false,
  slidesToScroll: 1,
  swipeToSlide: true,
  autoplay: false,
  speed: 1000,

  responsive: [
    {
      breakpoint: 1400,
      settings: {
        slidesToShow: 2,
      },
    },
    {
      breakpoint: 992,
      settings: {
        slidesToShow: 1,
      },
    },
    {
      breakpoint: 768,
      settings: {
        slidesToShow: 2,
      },
    },
    {
      breakpoint: 476,
      settings: {
        slidesToShow: 1,
      },
    },
  ],
});
$(".sldimg4").slick({
  arrows: true,
  dots: false,
  prevArrow:
    '<span class="prev_button"><img src="./img/01.png" alt=""></span>',
  nextArrow:
    '<span class="next_button"><img src="./img/02.png" alt=""></span>',
  infinite: true,
  slidesToShow: 4,
  pauseOnHover: false,
  dragable: false,
  slidesToScroll: 1,
  swipeToSlide: true,
  autoplay: false,
  speed: 1000,

  responsive: [
    {
      breakpoint: 1400,
      settings: {
        slidesToShow: 4,
      },
    },
    {
      breakpoint: 992,
      settings: {
        slidesToShow: 3,
      },
    },
    {
      breakpoint: 768,
      settings: {
        slidesToShow: 2,
      },
    },
    {
      breakpoint: 350,
      settings: {
        slidesToShow: 1,
      },
    },
  ],
});
$(".sldimg5").slick({
  arrows: true,
  dots: false,
  prevArrow:
    '<span class="prev_button"><img src="./img/01.png" alt=""></span>',
  nextArrow:
    '<span class="next_button"><img src="./img/02.png" alt=""></span>',
  infinite: true,
  slidesToShow: 4,
  pauseOnHover: false,
  dragable: false,
  slidesToScroll: 1,
  swipeToSlide: true,
  autoplay: false,
  speed: 1000,

  responsive: [
    {
      breakpoint: 1400,
      settings: {
        slidesToShow: 4,
      },
    },
    {
      breakpoint: 992,
      settings: {
        slidesToShow: 3,
      },
    },
    {
      breakpoint: 767,
      settings: {
        slidesToShow: 2,
      },
    },
    {
      breakpoint: 350,
      settings: {
        slidesToShow: 1,
      },
    },
  ],
});



function openNav() {
  document.getElementById("myNav").style.height = "100%";
}

/* Close */
function closeNav() {
  document.getElementById("myNav").style.height = "0%";
}