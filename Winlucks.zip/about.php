<!DOCTYPE html>
<html lang="en">

<head>
    <link rel="icon" type="image/png" sizes="16x16" href="./img/manthra-logo.png">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Winlucks</title>

    <?php
    include 'style.php';
    ?>

</head>

<body>

    <?php
    include 'header.php';
    ?>
    <div class="main">
        <section>
            <div class="abt1">
                <div class="container">
                    <h3 class="h3" data-aos="fade-in" data-aos-duration="1000">Shop With Winlucks</h3>
                    <div class="fr-up">
                        <h2 class="h2" data-aos="fade-up" data-aos-duration="1000" width="100%"> Winlucks brings
                            all the best<br> offers from every shop to a single screen.</h2>
                    </div>
                    <p data-aos="fade-in" data-aos-duration="1000">Our journey began with the vision to connect local vendors and customers on a trustworthy platform.
                        Through research, seed funding, meticulous planning, and phased launches, we developed a user-friendly mobile and web app that supports this idea.Our platform is now ready to create a marketplace that is ready to support local economies, fostering trust and connections for vendors and customers alike.</p>
                    <a href="contact.php">
                        <p class="cbt-ct magnetic" >Contact Us</p>
                    </a>
                    <img class="img-36" src="./img/45.png" alt="">
                    <img class="img-46" src="./img/46.png" alt="">
                </div>
            </div>
        </section>
        <section>
            <div class="abt2">
                <div class="container">
                    <div class="fr-up">
                        <h2 data-aos="fade-up" data-aos-duration="1000">🎉 Win Big with Our Giveaway! 🎉 Download now for a chance to score amazing prizes! 📱✨ </h2>
                    </div>
                    <p data-aos="fade-in" data-aos-duration="1000">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard </p>
                    <div class="rdy-btns">
                        <img class="magnetic" src="./img/24.png" alt="">
                        <img class="magnetic" src="./img/25.png" alt="">
                    </div>
                    <img class="img-1 srv-img-an2" src="./img/1.png" alt="">
                    <img class="img-37 srv-img-an2" src="./img/37.png" alt="">
                    <img class="img-21" src="./img/21.png" alt="">
                </div>
        </section>
        <section>
            <div class="abt3">
                <div class="container">
                    <div class="img-txt">
                        <div class="txt">
                            <div class="txs fr-in1" data-aos="fade-up" data-aos-duration="1000">
                                <h3>Lorem</h3>
                                <p>The best options from nearby shops, tailored to meet your affordability and quality preferences</p>
                            </div>
                            <div class="txs" data-aos="fade-up" data-aos-duration="1000">
                                <h3>Lorem</h3>
                                <p>The best options from nearby shops, tailored to meet your affordability and quality preferences</p>
                            </div>
                            <div class="txs fr-in1" data-aos="fade-up" data-aos-duration="1000">
                                <h3>Lorem</h3>
                                <p>The best options from nearby shops, tailored to meet your affordability and quality preferences</p>
                            </div>
                        </div>
                        <div class="ap">
                            <img class="img-38" src="./img/49.png" alt="">
                        </div>
                        <div class="txt">
                            <div class="txs fr-in2" data-aos="fade-up" data-aos-duration="1000">
                                <h3>Lorem</h3>
                                <p>The best options from nearby shops, tailored to meet your affordability and quality preferences</p>
                            </div>
                            <div class="txs" data-aos="fade-up" data-aos-duration="1000">
                                <h3>Lorem</h3>
                                <p>The best options from nearby shops, tailored to meet your affordability and quality preferences</p>
                            </div>
                            <div class="txs fr-in2" data-aos="fade-up" data-aos-duration="1000">
                                <h3>Lorem</h3>
                                <p>The best options from nearby shops, tailored to meet your affordability and quality preferences</p>
                            </div>
                        </div>
                    </div>
                </div>
        </section>
        <section class="abt4">
            <div class="container">
                <div class="ad-fl">
                    <div class="ad-img">
                        <div class="arw-bx inabt2" data-aos="fade-in" data-aos-duration="1000">
                            <div class="trimg in-abt2">
                                <img src="./img/40.png" alt="">
                            </div>
                            <div>
                                <div class="arw-bx-flx">
                                    <img class="img-42" src="./img/42.png" alt="">
                                    <h3>ONLY 3 HOURS LEFT</h3>
                                </div>
                                <p>Get 50% off on every product hurry up!!! Limited stock only</p>
                            </div>
                        </div>

                        <img class="img-39" src="./img/39.png" alt="" data-aos="fade-in" data-aos-duration="1000">
                        <div class="arw-bx inabt" data-aos="fade-in" data-aos-duration="1000">
                            <div class="trimg in-abt">
                                <img src="./img/41.png" alt="">
                            </div>
                            <div>
                                <div class="arw-bx-flx">
                                    <img class="img-42" src="./img/42.png" alt="">
                                    <h3>WINLUCKS</h3>
                                </div>
                                <p>Purchase with Winlucks coin to increase the chances of winning additional discounts and
                                    prizes.</p>
                            </div>
                        </div>
                    </div>
                    <div class="ad-txt" data-aos="fade-in" data-aos-duration="1000">
                        <h2>Getting you those addons is what exactly Winlucks does!</h2>
                        <p>Get all the free giveaways notified whenever your nearby shops announce a new one! No matter who you are, what you do, or where you come from</p>
                    </div>
                </div>
            </div>
        </section>

        <section>
            <div class="abt5">
                <div class="container">
                    <div>
                        <div class="fr-up">
                            <h2 class="h2" data-aos="fade-up" data-aos-duration="1000">Our Team</h2>
                        </div>
                        <p class="p1" data-aos="fade-in" data-aos-duration="1000">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard </p>
                        <img class="img-4" src="./img/4.png" alt="">
                        <img class="img-1 srv-img-an2" src="./img/1.png" alt="">
                    </div>
                    <div>
                        <div class="sldimg2" data-aos="fade-up" data-aos-duration="1000">
                            <div class="item">
                                <div class="img-bx">
                                    <img src="./img/23.png" alt="">
                                    <h3>John Doe</h3>
                                    <p class="p">CEO</p>
                                    <p class="p3">Lorem Ipsum is simply dummy text of the</p>

                                </div>
                            </div>
                            <div class="item">
                                <div class="img-bx">
                                    <img src="./img/23.png" alt="">
                                    <h3>John Doe</h3>
                                    <p class="p">CEO</p>
                                    <p class="p3">Lorem Ipsum is simply dummy text of the</p>

                                </div>
                            </div>
                            <div class="item">
                                <div class="img-bx">
                                    <img src="./img/23.png" alt="">
                                    <h3>John Doe</h3>
                                    <p class="p">CEO</p>
                                    <p class="p3">Lorem Ipsum is simply dummy text of the</p>

                                </div>
                            </div>
                            <div class="item">
                                <div class="img-bx">
                                    <img src="./img/23.png" alt="">
                                    <h3>John Doe</h3>
                                    <p class="p">CEO</p>
                                    <p class="p3">Lorem Ipsum is simply dummy text of the</p>

                                </div>
                            </div>
                            <div class="item">
                                <div class="img-bx">
                                    <img src="./img/23.png" alt="">
                                    <h3>John Doe</h3>
                                    <p class="p">CEO</p>
                                    <p class="p3">Lorem Ipsum is simply dummy text of the</p>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
        </section>

        <section>
            <div class="abt6">
                <div class="container">
                    <img class="img-43" src="./img/43.png" alt="">
                    <div class="row">
                        <div class="col-md-6 fr-rt">
                            <div class="ab6-hdng">
                                <div class="fr-up">
                                    <h2 class="h2" data-aos="fade-up" data-aos-duration="1000">Our Supporters</h2>
                                </div>
                            </div>
                            <div class="ab6-hdng" data-aos="fade-in" data-aos-duration="1000">
                                <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
                            </div>

                            <div class="sldimg3" data-aos="fade-up" data-aos-duration="1000">
                                <div class="item">
                                    <div class="img-bx">
                                        <img src="./img/23.png" alt="">
                                        <!-- <h3>John Doe</h3>
                                        <p class="p">CEO</p>
                                        <p class="p3">Lorem Ipsum is simply dummy text of the</p> -->
                                    </div>
                                </div>
                                <div class="item">
                                    <div class="img-bx">
                                        <img src="./img/23.png" alt="">
                                        <!-- <h3>John Doe</h3>
                                        <p class="p">CEO</p>
                                        <p class="p3">Lorem Ipsum is simply dummy text of the</p> -->
                                    </div>
                                </div>
                                <div class="item">
                                    <div class="img-bx">
                                        <img src="./img/23.png" alt="">
                                        <!-- <h3>John Doe</h3>
                                        <p class="p">CEO</p>
                                        <p class="p3">Lorem Ipsum is simply dummy text of the</p> -->
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="ab6-hdng">
                                <div class="fr-up">
                                    <h2 class="h2" data-aos="fade-up" data-aos-duration="1000">Our Influencers</h2>
                                </div>
                            </div>
                            <div class="ab6-hdng" data-aos="fade-in" data-aos-duration="1000">
                                <p >Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
                            </div>
                            <div class="sldimg3" data-aos="fade-up" data-aos-duration="1000">
                                <div class="item">
                                    <div class="img-bx">
                                        <img src="./img/23.png" alt="">
                                        <!-- <h3>John Doe</h3>
                                        <p class="p">CEO</p>
                                        <p class="p3">Lorem Ipsum is simply dummy text of the</p> -->
                                    </div>
                                </div>
                                <div class="item">
                                    <div class="img-bx">
                                        <img src="./img/23.png" alt="">
                                        <!-- <h3>John Doe</h3>
                                        <p class="p">CEO</p>
                                        <p class="p3">Lorem Ipsum is simply dummy text of the</p> -->
                                    </div>
                                </div>
                                <div class="item">
                                    <div class="img-bx">
                                        <img src="./img/23.png" alt="">
                                        <!-- <h3>John Doe</h3>
                                        <p class="p">CEO</p>
                                        <p class="p3">Lorem Ipsum is simply dummy text of the</p> -->
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- <section>
            <div class="abt5 scnd">
                <div class="container">
                    <div>
                        <div class="fr-up">
                            <h2 class="h2" data-aos="fade-up" data-aos-duration="1000">Our Consultants</h2>
                        </div>
                        <p class="p1">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard </p>
                        <img class="img-1 srv-img-an2" src="./img/1.png" alt="">
                    </div>
                    <div class="sldimg2">
                        <div class="item">
                            <div class="img-bx">
                                <img src="./img/23.png" alt="">
                                <h3>John Doe</h3>
                                <p class="p">CEO</p>
                                <p class="p3">Lorem Ipsum is simply dummy text of the</p>

                            </div>
                        </div>
                        <div class="item">
                            <div class="img-bx">
                                <img src="./img/23.png" alt="">
                                <h3>John Doe</h3>
                                <p class="p">CEO</p>
                                <p class="p3">Lorem Ipsum is simply dummy text of the</p>

                            </div>
                        </div>
                        <div class="item">
                            <div class="img-bx">
                                <img src="./img/23.png" alt="">
                                <h3>John Doe</h3>
                                <p class="p">CEO</p>
                                <p class="p3">Lorem Ipsum is simply dummy text of the</p>

                            </div>
                        </div>
                        <div class="item">
                            <div class="img-bx">
                                <img src="./img/23.png" alt="">
                                <h3>John Doe</h3>
                                <p class="p">CEO</p>
                                <p class="p3">Lorem Ipsum is simply dummy text of the</p>

                            </div>
                        </div>
                        <div class="item">
                            <div class="img-bx">
                                <img src="./img/23.png" alt="">
                                <h3>John Doe</h3>
                                <p class="p">CEO</p>
                                <p class="p3">Lorem Ipsum is simply dummy text of the</p>
                            </div>
                        </div>
                    </div>
                </div>
        </section> -->

        <section class="rdy-dwnld inabt">
            <div class="rdy-txt">
                <div class="fr-up">
                    <h2 data-aos="fade-up" data-aos-duration="1000">Ready To Download</h2>
                </div>
                <p data-aos="fade-in" data-aos-duration="1000">Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
                <div class="rdy-btns">
                    <img class="magnetic" src="./img/24.png" alt="">
                    <img class="magnetic" src="./img/25.png" alt="">
                </div>
            </div>
        </section>

    </div>


    <?php
    include 'footer.php';
    ?>
    <script src="js/in-one.js"></script>
</body>

</html>