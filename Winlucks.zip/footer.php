<footer>
    <div class="container">
        <div class="foot-conts">
            <div class="foot-logo">
                <div>
                <img src="./img/log.png" alt="Logo">
                <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
                </div>
            </div>
            <div class="ulsflx2">
                <div class="uls">
                    <h3>Quick links</h3>
                    <ul>
                        <li><a href="index.php">
                                <p>Home</p>
                            </a></li>
                        <li><a href="about.php">
                                <p>About Us</p>
                            </a></li>
                        <li><a href="packages.php">
                                <p>Packages</p>
                            </a></li>
                        <li><a href="contact.php">
                                <p>Contact</p>
                            </a></li>
                    </ul>
                </div>
                <div class="uls">
                    <h3>Connect our team in U.A.E</h3>
                    <ul>
                        <li><a href="#"><i class="fa-solid fa-location-crosshairs"></i>
                                <p>Meydan Grandstand, 6th floor, Meydan Road, Nad Al Sheba, Dubai, U.A.E</p>
                            </a></li>
                        <li><a href="mailto:Info@winlucks.com"><i class="fa-solid fa-envelope"></i>
                                <p> Info@winlucks.com</p>
                            </a></li>
                        <li><a href="tel:+971522833003"><i class="fa-solid fa-mobile-screen-button"></i>
                                <p>+97 1522 833 003</p>
                            </a></li>
                    </ul>
                </div>
            </div>
            <div class="ulsflx">
                <div class="uls">
                    <h3>Connect our team in kerala</h3>
                    <ul class="loc">
                        <ul>
                            <li><p class="cmpny-nm"> Zraple Tech LLP</p></li>
                            <li><a href="#"><i class="fa-solid fa-location-crosshairs"></i>
                                    <p> 5/447 A, MANIKKAPPARA, Kuttippala, KALPAKANCHERI, Tirur, Malappuram- 676501, Kerala, India</p>
                                </a></li>
                            <!-- <li><a href="mailto:Info@winlucks.com"><i class="fa-solid fa-envelope"></i>
                            <p> Info@winlucks.com</p>
                        </a></li> -->
                            <li><a href="tel:+918921377177"><i class="fa-solid fa-mobile-screen-button"></i>
                                    <p>+91 8921 377 177</p>
                                </a></li>
                        </ul>

                    </ul>
                </div>
                <div class="uls">
                    <ul class="loc">
                        <h3>Follow Us</h3>
                        <p class="p">Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
                        <div class="scl">
                            <a href=""><img src="./img/28.png" alt=""></a>
                            <a href=""><img src="./img/27.png" alt=""></a>
                            <a href=""><img src="./img/29.png" alt=""></a>
                            <a href=""><img src="./img/26.png" alt=""></a>
                        </div>
                        <div class="pymnt">
                            <div>
                                <div>
                                    <p>Payment Accepted</p>
                                </div>
                                <div class="pays">
                                    <img src="./img/30.png" alt="">
                                    <img src="./img/31.png" alt="">
                                    <img src="./img/32.png" alt="">
                                    <!-- <img src="./img/33.png" alt="">
                                <img src="./img/34.png" alt="">
                                <img src="./img/35.png" alt=""> -->
                                </div>
                            </div>
                        </div>

                    </ul>
                </div>
            </div>
        </div>
    </div>

    <div class="copy-right">
        <p>©
            Copyright 2024 Winlucks | All Rights Reserved</a></p>
    </div>




    <div class="bk-tp-btn ">
        <div class="srv-img-an2">
            <button onclick="topFunction()" id="tp-Btn" style="opacity: 0" title="Go to top"><i class="fa-solid fa-chevron-up"></i></button>
        </div>
    </div>



</footer>


<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js" integrity="sha512-v2CJ7UaYy4JwqLDIrZUI/4hqeoQieOmAZNXBeQyjo21dadnwR+8ZaIJVT8EE2iyI61OV8e6M8PP2/4hpQINQ/g==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.2/gsap.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.2/ScrollTrigger.min.js"></script>
<script src="https://unpkg.com/gsap@3/dist/SplitText.js"></script>
<script src="https://cdn.jsdelivr.net/gh/studio-freight/lenis@1.0.27/bundled/lenis.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/jquery.ripples@0.6.3/dist/jquery.ripples.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/swiper@10/swiper-bundle.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/animejs/3.2.2/anime.min.js" integrity="sha512-aNMyYYxdIxIaot0Y1/PLuEu3eipGCmsEUBrUq+7aVyPGMFH8z0eTP0tkqAvv34fzN6z+201d3T8HPb1svWSKHQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script type="text/javascript" src="//cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/magnific-popup.js/1.1.0/jquery.magnific-popup.min.js" integrity="sha512-IsNh5E3eYy3tr/JiX2Yx4vsCujtkhwl7SLqgnwLNgf04Hrt9BT9SXlLlZlWx+OK4ndzAoALhsMNcCmkggjZB1w==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script src="js/ss.js"></script>
<script src="js/main.js"></script>
<script src="js/slide.js"></script>
<script>
    AOS.init({
        once: true,
    });
</script>