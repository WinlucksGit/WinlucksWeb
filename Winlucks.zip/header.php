<header class="header">

    <div class="container">
        <div class="hdr-flx">
            <div class="hdr-logo">
                <a href="index.php"><img src="./img/log.png" alt="Logo"></a>
            </div>
            <div class="pages">
                <ul>
                    <li><a href="index.php" class="fr-und-ln">Home</a></li>
                    <li><a href="about.php" class="fr-und-ln">About</a></li>
                    <li><a href="packages.php" class="fr-und-ln">Packages</a></li>
                </ul>
            </div>
            <div class="ct-btn-br">
                <div class="ct-btn magnetic"><a href="contact.php">
                        <p>Contact Us</p>
                    </a></div>
                <div class=" fr-mob toggle ">
                    <div class="toggle_icon">
                        <span></span>
                        <span></span>
                        <span></span>
                    </div>
                </div>
            </div>
        </div>
    </div>



    <div class="navs">
        <div class="container ">
            <div class=" nav-conts ">
                <div class="nav-con">
                    <div>
                        <div class=" fr-mbs">
                            <div>
                                <ul>
                                    <li><a href="index.php" class="fr-und-ln">Home</a></li>
                                    <li><a href="about.php" class="fr-und-ln">About</a></li>
                                    <li><a href="packages.php" class="fr-und-ln">packages</a></li>
                                    <li><a href="contact.php" class="fr-und-ln">Contact</a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="">
                            <div class="foot-icon mb-btm">
                                <a href=""><a href=""><i class="fa-brands fa-square-facebook"></i></a>
                                    <a href=""><i class="fa-brands fa-whatsapp"></i></a>
                                    <a href=""><i class="fa-brands fa-instagram"></i></a>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>



</header>