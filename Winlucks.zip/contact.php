<!DOCTYPE html>
<html lang="en">

<head>
    <link rel="icon" type="image/png" sizes="16x16" href="./img/manthra-logo.png">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Winlucks</title>

    <?php
    include 'style.php';
    ?>

</head>

<body>

    <?php
    include 'header.php';
    ?>
    <div class="main">
        <section class="ct-1">
            <div class="container">
                <h3 class="h3" data-aos="fade-in" data-aos-duration="1000">Shop With Winlucks</h3>
                <div class="fr-up">
                    <h2 class="h2" data-aos="fade-up" data-aos-duration="1000">Discover a wide range of products right at your fingertips!</h2>
                </div>
                <p class="p1" data-aos="fade-in" data-aos-duration="1000">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard </p>
                <img class="img-44" src="./img/44.png" alt="">
            </div>
        </section>
        <section>
            <div class="ct-2">
                <div class="container">
                    <div class="row">
                        <div class="col-md-6 inct">
                            <div class="cnt-det">
                                <div class="uls" data-aos="fade-up" data-aos-duration="1000">
                                    <h3>Connect our team in U.A.E</h3>
                                    <div class="cnt-det-flx">
                                        <i class="fa-solid fa-location-dot"></i>
                                        <p>Meydan Grandstand, 6th floor, Meydan Road, Nad Al Sheba, Dubai, U.A.E</p>
                                    </div>
                                    <div class="cnt-det-flx">
                                        <i class="fa-solid fa-envelope"></i>
                                        <a href="mailto:Info@winlucks.com">
                                            <p> Info@winlucks.com</p>
                                        </a>
                                    </div>
                                    <div class="cnt-det-flx">
                                        <i class="fa-solid fa-phone"></i>
                                        <a href="tel:+971522833003">
                                            <p>+97 1522 833 003</p>
                                        </a>
                                    </div>
                                </div>
                                <div class="uls" data-aos="fade-up" data-aos-duration="1000">
                                    <h3>Connect our team in kerala</h3>
                                    <p style="margin-left:40px; margin-bottom: -20px"> Zraple Tech LLP</p>
                                    <div class="cnt-det-flx">
                                        <i class="fa-solid fa-location-dot"></i>
                                        <p>5/447 A, MANIKKAPPARA, Kuttippala, KALPAKANCHERI, Tirur, Malappuram- 676501, Kerala, India</p>
                                    </div>
                                    <!-- <div class="cnt-det-flx">
                                        <i class="fa-solid fa-envelope"></i>
                                        <a href="mailto:Info@winlucks.com">
                                            <p> Info@winlucks.com</p>
                                        </a>
                                    </div> -->
                                    <div class="cnt-det-flx">
                                        <i class="fa-solid fa-phone"></i>
                                        <a href="tel:+91 8921 377 177">
                                            <p>+91 8921 377 177</p>
                                        </a>
                                    </div>
                                    <div class="scl">
                                        <a href=""><img src="./img/28.png" alt=""></a>
                                        <a href=""><img src="./img/27.png" alt=""></a>
                                        <a href=""><img src="./img/29.png" alt=""></a>
                                        <a href=""><img src="./img/26.png" alt=""></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 inct">
                            <div class="cnt-frm">
                                <h2>Get A Free Quote </h2>
                                <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
                                <div class="cnt-frm-inp">
                                    <form>
                                        <div>
                                            <input type="text" placeholder="Name">
                                        </div>
                                        <div>
                                            <input type="Email" placeholder="Email">
                                        </div>
                                        <div>
                                            <input type="number" placeholder="Phone">
                                        </div>
                                        <div>
                                            <textarea name="Massage" placeholder="Massage" id=""></textarea>
                                        </div>
                                        <button>
                                            <p>Submit</p>
                                        </button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="map" data-aos="fade-in" data-aos-duration="1000">
                        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d37252.44885347801!2d76.04767848165244!3d11.062500797377284!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3ba64a9be29b058f%3A0x23e371e0d4c30d8e!2sMalappuram%2C%20Kerala!5e0!3m2!1sen!2sin!4v1721815834467!5m2!1sen!2sin" width="100%" height="100%" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                    </div>
                    <div class="map" data-aos="fade-in" data-aos-duration="1000">
                        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d37252.44885347801!2d76.04767848165244!3d11.062500797377284!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3ba64a9be29b058f%3A0x23e371e0d4c30d8e!2sMalappuram%2C%20Kerala!5e0!3m2!1sen!2sin!4v1721815834467!5m2!1sen!2sin" width="100%" height="100%" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                    </div>
                    <section>
                        <div class="ct-slide">
                            <div class="ab6-hdng">
                                <div class="fr-up">
                                    <h2 class="h2" data-aos="fade-up" data-aos-duration="1000">Our Lorem ipsom</h2>
                                </div>
                            </div>
                            <div class="ab6-hdng inct">
                                <p data-aos="fade-in" data-aos-duration="1000">Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
                            </div>
                        </div>
                        <div class="sldimg4" data-aos="fade-up" data-aos-duration="1000">
                            <div class="item2">
                                <div class="img-bx">
                                    <img src="./img/23.png" alt="">
                                </div>
                            </div>
                            <div class="item2">
                                <div class="img-bx">
                                    <img src="./img/23.png" alt="">
                                </div>
                            </div>
                            <div class="item2">
                                <div class="img-bx">
                                    <img src="./img/23.png" alt="">
                                </div>
                            </div>
                            <div class="item2">
                                <div class="img-bx">
                                    <img src="./img/23.png" alt="">
                                </div>
                            </div>
                            <div class="item2">
                                <div class="img-bx">
                                    <img src="./img/23.png" alt="">
                                </div>
                            </div>
                            <div class="item2">
                                <div class="img-bx">
                                    <img src="./img/23.png" alt="">
                                </div>
                            </div>
                            <div class="item2">
                                <div class="img-bx">
                                    <img src="./img/23.png" alt="">
                                </div>
                            </div>
                        </div>
                    </section>
                </div>
            </div>
        </section>
    </div>


    <?php
    include 'footer.php';
    ?>
    <script src="js/in-one.js"></script>
</body>

</html>